# Backend integration scaffold

No production backend is included or deployed. This folder documents the secure boundary required for real integrations.

Recommended endpoints:
- `POST /v1/tasks` — create a task plan
- `GET /v1/tasks` — list tasks and statuses
- `POST /v1/actions/{id}/approve` — approve one exact preview
- `POST /v1/actions/{id}/reject` — reject one exact preview
- `GET /v1/connections` — show connected providers
- `POST /v1/oauth/{provider}/start` and callback — OAuth authorization-code flow with PKCE where supported
- `DELETE /v1/connections/{provider}` — revoke/disconnect

Production requirements: TLS, authenticated user sessions, CSRF/state validation, PKCE, encrypted server-side token storage, strict scopes, audit logs, rate limits, idempotency keys, webhook signature validation, deletion/export controls, and explicit approval for publishing, sending messages, accepting orders, or making price commitments.

Never accept a user's social password, OTP, browser cookie, or session token.
